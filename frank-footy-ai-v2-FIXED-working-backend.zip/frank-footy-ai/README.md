# Frank Footy AI V2 — Fixed Build

## Why the previous screen showed "Server error"

The dashboard is a frontend that calls a Node/Express backend. Opening `public/index.html` directly on an Android phone does NOT start that backend, so browser requests such as `/api/health` and `/api/fixtures` fail.

The previous package also did not declare Express as a dependency. This fixed build adds it.

## What this build contains

- Global fixtures
- API-Football predictions
- Odds retrieval from API-Football
- 1X2 probabilities
- Double Chance screening
- Over 1.5 / Over 2.5 / Under 3.5 / BTTS probabilities
- Automatic accumulator candidates
- Server-side API key
- Mobile-friendly dashboard
- Clear backend/API-key diagnostics

## Run on a computer

Requirements: Node.js 18+.

```bash
npm install
```

Create `.env` from `.env.example` and set:

```text
API_FOOTBALL_KEY=YOUR_API_FOOTBALL_KEY
```

Then:

```bash
npm start
```

Open:

```text
http://localhost:3000
```

## Put it online so it works from your Android phone

A simple deployment option is Render.

1. Put this project in a GitHub repository.
2. Create a Render Web Service from that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add an environment variable:
   - Key: `API_FOOTBALL_KEY`
   - Value: your API-Football key
6. Deploy.
7. Open the Render URL on your Android phone.

Do NOT put the API key inside `public/app.js` or `public/index.html`.

## API key

This application uses the API-Football key through the server-side `x-apisports-key` header. The browser never needs to receive the key.

## Important

Predictions are probabilities, not guarantees. The accumulator is a screening feature and should be evaluated with historical results/backtesting before being relied on for financial decisions.

## Next engineering upgrade

For a stronger production system, add:
- database-backed prediction history
- automatic result settlement
- historical backtesting
- calibrated probabilities
- bookmaker-specific odds/value/edge
- injuries and suspensions
- confirmed lineups
- team statistics and recent form
- scheduled background refresh
- caching/rate-limit protection
