// Frank Footy AI V2 prediction helpers.
// The production server owns the API key and performs API-Football requests.
// This module is intentionally dependency-free so the model can be tested independently.

function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
function poisson(k,l){
  if(l<=0)return k===0?1:0;
  let p=Math.exp(-l);
  for(let i=1;i<=k;i++)p*=l/i;
  return p;
}
function predict({homeGoalsFor=1.35,awayGoalsFor=1.05,homeGoalsAgainst=1.10,awayGoalsAgainst=1.25}={}){
  const hx=clamp(homeGoalsFor*.62+awayGoalsAgainst*.38+.18,.15,4.5);
  const ax=clamp(awayGoalsFor*.62+homeGoalsAgainst*.38-.05,.1,4);
  let H=0,D=0,A=0,O15=0,O25=0,U35=0,B=0,best={p:0,h:0,a:0};
  for(let h=0;h<=7;h++)for(let a=0;a<=7;a++){
    const p=poisson(h,hx)*poisson(a,ax);
    if(h>a)H+=p;else if(h===a)D+=p;else A+=p;
    if(h+a>=2)O15+=p;if(h+a>=3)O25+=p;if(h+a<=3)U35+=p;if(h&&a)B+=p;
    if(p>best.p)best={p,h,a};
  }
  const s=H+D+A||1;
  return {xgHome:+hx.toFixed(2),xgAway:+ax.toFixed(2),homeWin:+(100*H/s).toFixed(1),draw:+(100*D/s).toFixed(1),awayWin:+(100*A/s).toFixed(1),over15:+(100*O15).toFixed(1),over25:+(100*O25).toFixed(1),under35:+(100*U35).toFixed(1),btts:+(100*B).toFixed(1),score:`${best.h}-${best.a}`,scoreProbability:+(100*best.p).toFixed(1)};
}
module.exports={predict};
