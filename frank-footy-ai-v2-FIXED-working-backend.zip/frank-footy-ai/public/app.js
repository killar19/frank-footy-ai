const $=s=>document.querySelector(s);
const dateEl=$("#date"), matches=$("#matches"), msg=$("#message"), status=$("#status"), accBox=$("#accBox"), accList=$("#accList");
dateEl.value=new Date().toISOString().slice(0,10);

function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function get(url){const r=await fetch(url);const d=await r.json();if(!r.ok)throw new Error(d.error||"Request failed");return d;}
async function health(){
  try{
    const d=await get("/api/health");
    status.textContent=d.apiConfigured?"API connected":"API key missing";
    status.title=d.message||"";
    if(!d.apiConfigured) msg.textContent="Backend is online, but the API-Football key has not been configured.";
  }catch(e){
    status.textContent="Backend offline";
    msg.textContent="The web page is open, but the Frank Footy backend is not running at this address. Deploy/run the Node server, then open its URL.";
  }
}
function fixtureCard(f){
 const id=f.fixture?.id, h=f.teams?.home?.name||"Home", a=f.teams?.away?.name||"Away";
 const time=new Date(f.fixture?.date).toLocaleString("en-GH",{dateStyle:"medium",timeStyle:"short"});
 return `<article class="card"><div class="muted">${esc(f.league?.country||"")} • ${esc(f.league?.name||"")} • ${esc(time)}</div><h3>${esc(h)} vs ${esc(a)}</h3><div id="p-${id}" class="muted">Loading analysis…</div><div class="actions"><button data-id="${id}">Analyze match</button></div></article>`;
}
async function load(){
 msg.textContent="Loading global fixtures…"; matches.innerHTML="";
 try{
  const d=await get("/api/fixtures?date="+encodeURIComponent(dateEl.value));
  const fs=(d.response||[]).filter(x=>["NS","TBD"].includes(x.fixture?.status?.short));
  $("#count").textContent=`${fs.length} upcoming`;
  matches.innerHTML=fs.slice(0,40).map(fixtureCard).join("")||"<div class='panel'>No upcoming fixtures returned for this date.</div>";
  fs.slice(0,40).forEach(async f=>{
    try{
      const d=await get("/api/analysis/"+f.fixture.id), p=d.apiModel;
      const el=$("#p-"+f.fixture.id); if(!el||!p)return;
      el.innerHTML=`<div class="pred"><div><span>Home</span><b>${p.homeWin}%</b></div><div><span>Draw</span><b>${p.draw}%</b></div><div><span>Away</span><b>${p.awayWin}%</b></div></div><div class="chips"><span class="chip">API: ${esc(p.advice)}</span><span class="chip">Score ${esc(p.score||"—")}</span></div>`;
    }catch(_){}
  });
  msg.textContent="";
 }catch(e){msg.textContent=e.message}
}
matches.addEventListener("click",async e=>{
 const b=e.target.closest("button[data-id]");if(!b)return;
 const id=b.dataset.id;b.disabled=true;b.textContent="Analyzing…";
 try{
  const d=await get("/api/prediction/"+id);
  const p=d.prediction?.predictions||{};const odds=d.odds||[];
  const el=$("#p-"+id);
  const pct=p.percent||{};
  el.innerHTML=`<div class="pred"><div>Home<b>${esc(pct.home||"—")}%</b></div><div>Draw<b>${esc(pct.draw||"—")}%</b></div><div>Away<b>${esc(pct.away||"—")}%</b></div></div><div class="chips"><span class="chip">${esc(p.advice||"No advice")}</span><span class="chip">${esc(p.under_over||"—")}</span><span class="chip">Model ${esc(p.goals?.home||"?")}-${esc(p.goals?.away||"?")}</span></div><p class="muted">Best available odds: ${odds.slice(0,5).map(o=>`${esc(o.market)} ${esc(o.selection)} @ ${o.odd}`).join(" • ")||"not available"}</p>`;
 }catch(err){msg.textContent=err.message}
 b.disabled=false;b.textContent="Analyze match";
});
$("#load").addEventListener("click",load);
$("#acc").addEventListener("click",async()=>{
 accBox.classList.remove("hidden");accList.textContent="Building…";
 try{
  const d=await get("/api/accumulator?date="+encodeURIComponent(dateEl.value));
  accList.innerHTML=d.candidates.length?d.candidates.map(x=>`<div class="ticket"><b>${esc(x.home)} vs ${esc(x.away)}</b><br><span class="muted">${esc(x.market)} • ${x.probability}% model probability • ${new Date(x.kickoff).toLocaleTimeString("en-GH",{hour:"2-digit",minute:"2-digit"})}</span></div>`).join(""):"<p class='muted'>No candidates met the 70% screening threshold.</p>";
 }catch(e){accList.textContent=e.message}
});
health();load();
