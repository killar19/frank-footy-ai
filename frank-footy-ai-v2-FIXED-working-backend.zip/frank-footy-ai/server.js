const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_FOOTBALL_KEY || "";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function apiHeaders() {
  return { "x-apisports-key": API_KEY };
}

async function apiFootball(endpoint, params = {}) {
  if (!API_KEY) throw new Error("API_FOOTBALL_KEY is not configured. Add it to the server environment and restart.");
  const url = new URL(`https://v3.football.api-sports.io/${endpoint}`);
  Object.entries(params).forEach(([k,v]) => {
    if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
  });
  const r = await fetch(url, { headers: apiHeaders() });
  if (!r.ok) throw new Error(`API-Football HTTP ${r.status}`);
  const data = await r.json();
  if (data.errors && Object.keys(data.errors).length) {
    throw new Error(Object.values(data.errors).join("; "));
  }
  return data;
}

function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }

function poisson(k, lambda) {
  if (lambda <= 0) return k === 0 ? 1 : 0;
  let p = Math.exp(-lambda);
  for (let i=1; i<=k; i++) p *= lambda/i;
  return p;
}

function modelMatch(home, away) {
  const hg = Number(home.avgGoalsFor ?? 1.35);
  const ag = Number(away.avgGoalsFor ?? 1.05);
  const hd = Number(home.avgGoalsAgainst ?? 1.10);
  const ad = Number(away.avgGoalsAgainst ?? 1.25);

  const homeXg = clamp((hg * 0.62 + ad * 0.38) + 0.18, 0.15, 4.5);
  const awayXg = clamp((ag * 0.62 + hd * 0.38) - 0.05, 0.10, 4.0);

  let pH=0,pD=0,pA=0,pO15=0,pO25=0,pU35=0,pBTTS=0;
  const scores=[];
  for(let h=0;h<=7;h++){
    for(let a=0;a<=7;a++){
      const p=poisson(h,homeXg)*poisson(a,awayXg);
      scores.push({h,a,p});
      if(h>a)pH+=p; else if(h===a)pD+=p; else pA+=p;
      if(h+a>=2)pO15+=p;
      if(h+a>=3)pO25+=p;
      if(h+a<=3)pU35+=p;
      if(h>=1 && a>=1)pBTTS+=p;
    }
  }
  const total=pH+pD+pA || 1;
  pH/=total;pD/=total;pA/=total;
  scores.sort((x,y)=>y.p-x.p);
  const top=scores[0];
  return {
    xgHome: +homeXg.toFixed(2), xgAway:+awayXg.toFixed(2),
    homeWin:+(pH*100).toFixed(1), draw:+(pD*100).toFixed(1), awayWin:+(pA*100).toFixed(1),
    over15:+(pO15*100).toFixed(1), over25:+(pO25*100).toFixed(1),
    under35:+(pU35*100).toFixed(1), btts:+(pBTTS*100).toFixed(1),
    score:`${top.h}-${top.a}`, scoreProbability:+(top.p*100).toFixed(1)
  };
}

function normalizeOdds(odds) {
  const out = {};
  for (const bookmaker of (odds || [])) {
    for (const bet of (bookmaker.bets || [])) {
      for (const v of (bet.values || [])) {
        const key = `${bet.name}|${v.value}`;
        const odd = Number(v.odd);
        if (!Number.isFinite(odd)) continue;
        if (!out[key] || odd > out[key].odd) out[key] = {
          odd, bookmaker: bookmaker.name, market: bet.name, selection: v.value
        };
      }
    }
  }
  return Object.values(out);
}

function implied(odd) { return odd > 0 ? 1/odd : 0; }

app.get("/api/health", (req,res)=>res.json({
  ok:true,
  apiConfigured:!!API_KEY,
  service:"Frank Footy AI V2",
  message: API_KEY ? "Backend online and API key configured." : "Backend online, but API_FOOTBALL_KEY is missing."
}));

app.get("/api/fixtures", async (req,res)=>{
  try {
    const date = req.query.date || new Date().toISOString().slice(0,10);
    const data = await apiFootball("fixtures", { date, timezone: "Africa/Accra" });
    res.json(data);
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("/api/prediction/:fixture", async (req,res)=>{
  try {
    const id=req.params.fixture;
    const [pred, odds] = await Promise.all([
      apiFootball("predictions",{fixture:id}),
      apiFootball("odds",{fixture:id})
    ]);
    res.json({
      prediction: pred.response?.[0] || null,
      odds: normalizeOdds(odds.response?.[0]?.bookmakers || [])
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("/api/analysis/:fixture", async (req,res)=>{
  try {
    const id=req.params.fixture;
    const base = await apiFootball("predictions",{fixture:id});
    const p=base.response?.[0];
    if(!p) return res.json({available:false});
    const home=p.teams?.home, away=p.teams?.away;
    const pp=p.predictions || {};
    const percent=pp.percent || {};
    const apiModel={
      homeWin: parseFloat(percent.home)||0,
      draw: parseFloat(percent.draw)||0,
      awayWin: parseFloat(percent.away)||0,
      advice: pp.advice || "No API advice",
      underOver: pp.under_over || null,
      score: pp.goals ? `${pp.goals.home}-${pp.goals.away}` : null
    };
    res.json({available:true, fixture:{home,away}, apiModel});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("/api/accumulator", async (req,res)=>{
  try {
    const date=req.query.date || new Date().toISOString().slice(0,10);
    const fixtures=(await apiFootball("fixtures",{date,timezone:"Africa/Accra"})).response || [];
    const candidates=[];
    // Conservative automatic filtering: only markets with probability >= 70%.
    for(const f of fixtures.slice(0,40)){
      const id=f.fixture?.id;
      try {
        const p=(await apiFootball("predictions",{fixture:id})).response?.[0];
        if(!p) continue;
        const pct=p.predictions?.percent || {};
        const home=Number(pct.home)||0, draw=Number(pct.draw)||0, away=Number(pct.away)||0;
        const opts=[
          {market:"1X", probability:home+draw},
          {market:"X2", probability:draw+away},
          {market:"1", probability:home},
          {market:"X", probability:draw},
          {market:"2", probability:away}
        ].sort((a,b)=>b.probability-a.probability);
        const best=opts[0];
        if(best.probability>=70) candidates.push({
          fixtureId:id,
          home:f.teams?.home?.name, away:f.teams?.away?.name,
          kickoff:f.fixture?.date, market:best.market,
          probability:+best.probability.toFixed(1)
        });
      }catch(_){}
    }
    candidates.sort((a,b)=>b.probability-a.probability);
    res.json({date,candidates:candidates.slice(0,12)});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.listen(PORT, ()=>console.log(`Frank Footy AI V2 running on port ${PORT}`));
